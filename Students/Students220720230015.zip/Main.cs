﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Students
{
	public partial class Main : Form
	{
		// Do zapisu ścieżki najlepiej użyć metody Combine() z klasy Path, wtedy nasza ścieżka poddana jest walidacji. Dzięki temu będziemy pewni że nasza ścieżka jest prawidłowa i nie będzie żadnego problemu ze slashami.
		private string _filePath =
			Path.Combine(Environment.CurrentDirectory, "students.txt");

		public Main()
		{
			InitializeComponent();

			var students = DeserializeFromFile();
			dgvDiary.DataSource = students;
		}

		public void SerializeToFile(List<Student> students)
		{
			// using System.Xml.Serialization;
			// Jako parametr przekazujemy typ obiektu który chcemy serializować.
			// typeof() zwraca typ podczas kompilacji.
			var serializer = new XmlSerializer(typeof(List<Student>));

			using (var streamWriter = new StreamWriter(_filePath))
			{
				// Jako parametr musimy przekazać obiekt klasy Stream oraz listę obiektów.
				serializer.Serialize(streamWriter, students);
				// Należy pamiętać o zammknięciu strumienia, należy użyć metody Close().
				streamWriter.Close();

				// Z obiektami Stream jest jeszcze jeden problem, musimy ręcznie usunąć je z pamięci. Możemy to zrobić poprzez użycie metody Dispose() na obiekcie. Może się jednak zdarzyć że metoda Serialize() wyrzuci nam wyjątek i kod poniżej się nie wykona, czyli metody Close() i Dispose() nie zostaną wywołane. Przez co obiekt nie zostanie usunięty z pamięci i dopiero ponowne uruchomienie komputera rozwiązałoby problem, w związku z tym konieczne musimy zapewnić wykonanie metody Dispose().
				// **********
				// Metoda I
				// try...finally -> wywołanie Dispose() umieszczamy w klauzuli finally, pamiętając że deklaracja (i inicjalizacja (np. nullem)) obiektu musi nastąpić przed klauzulą try.
				// **********
				// Metoda II - lepszy - słowo kluczowe using
				// Jeżeli w using jest deklaracja jakiegoś obiektu, to zawsze, w każdym przypadku na koniec po wykonaniu różnych operacji zostanie na tym obiekcie wywołana metoda Dispose().

				// Stream jest to klasa która nam zapewnia transfer bajtów, odczytywanie i zapisywanie (możemy przekazać obie klasy - tutaj StreamWriter).
				// StreamWriter - gotowa klasa w namespace System.IO.
			}
		}

		public List<Student> DeserializeFromFile()
		{
			if (!File.Exists(_filePath))
			{
				// Jeśli plik nie istnieje zwróć pustą listę.
				return new List<Student>();
			}

			var serializer = new XmlSerializer(typeof(List<Student>));

			using (var streamReader = new StreamReader(_filePath))
			{
				// Metoda Deserialize() zwraca typ object, dlatego należy go rzutować.
				var students = (List<Student>)serializer.Deserialize(streamReader);
				streamReader.Close();
				return students;
			}
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			// Wyświetlanie okienka klasy AddEditStudent
			// Tworzymy nową instancję.
			var addEditStudent = new AddEditStudent();
			// Otwieramy formatkę jako nowe okno.
			addEditStudent.ShowDialog();
		}

		private void btnEdit_Click(object sender, EventArgs e)
		{
			if (dgvDiary.SelectedRows.Count == 0)
			{
				MessageBox.Show("Proszę zaznacz ucznia, którego dane chcesz edytować.");
				return; // Dalszy kod zostanie pominięty, wyjdziemy z metody.
			}

			// Convert.ToInt32(dgvDiary.SelectedRows[0].Cells[0].Value).
			// Pierwszy zaznaczony wierwsz, pierwsza kolumna i jej wartość.
			// Zwracany jest object -> konieczne rzutowanie na int.
			var addEditStudent = new AddEditStudent(
				Convert.ToInt32(dgvDiary.SelectedRows[0].Cells[0].Value));
			addEditStudent.ShowDialog();
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (dgvDiary.SelectedRows.Count == 0)
			{
				MessageBox.Show("Proszę zaznacz ucznia, którego chcesz usunąć.");
				return; // Dalszy kod zostanie pominięty, wyjdziemy z metody.
			}

			var selectedStudent = dgvDiary.SelectedRows[0];

			var mboxStudent =
				(selectedStudent.Cells[1].Value.ToString() + " " +
				selectedStudent.Cells[2].Value.ToString()).Trim();

			// OKCancel zwraca DialogResult
			var confirmDelete =
				MessageBox.Show($"Czy na pewno chcesz usunąć ucznia {mboxStudent}?",
				"Usuwanie ucznia",
				MessageBoxButtons.OKCancel);

			if (confirmDelete == DialogResult.OK)
			{
				var students = DeserializeFromFile();
				students.RemoveAll(x =>
					x.Id == Convert.ToInt32(selectedStudent.Cells[0].Value));
				SerializeToFile(students);
				dgvDiary.DataSource = students;
			}

		}

		private void btnRefresh_Click(object sender, EventArgs e)
		{
			var students = DeserializeFromFile();
			dgvDiary.DataSource = students;
		}
	}
}
